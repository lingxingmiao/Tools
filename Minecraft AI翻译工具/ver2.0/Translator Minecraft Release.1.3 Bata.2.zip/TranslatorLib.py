import multiprocessing as mp
import threading as mt
import hashlib
import zipfile
import pickle
import json
import ast
import os
import re

from functools import partial
from collections import defaultdict
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from TranslatorConfig import Config
from TranslatorQuantization import Quantization
from TranslatorModule import Module

import faiss

try:
    if not Config.GPU_ACC: raise ValueError("Config.GPU_ACC is set to False, skipping CUDA initialization")
    import cupy as np
    if not Config.GPU_DEVICE_ID == None:
        np.cuda.runtime.setDevice(Config.GPU_DEVICE_ID)
    np.dot(np.random.rand(2, 2), np.random.rand(2, 2))
    if not np.cuda.is_available(): raise ValueError("CUDA acceleration is not available")
except:
    import numpy as np

import requests
from tqdm import tqdm

Path(Config.VEC_FILE_PATH).mkdir(parents=True, exist_ok=True)
Path(Config.PATH_CACHE).mkdir(parents=True, exist_ok=True)
Path(Config.TRANSLATOR_CACHE_PATH).mkdir(parents=True, exist_ok=True)

class Translator:
    嵌入模型 = None
    上下文 = []
    线程锁 = mt.Lock()
    def 文本生成向量(text: list, outputs: list = None) -> np.float32:
        global 嵌入模型
        重试次数 = 0
        if not Config.EMB_API_URL and Config.EMB_MODEL:
            with Translator.线程锁:
                try:
                    向量列表 = 嵌入模型.encode(text)
                    向量列表 = np.array(向量列表).astype(np.float32)
                    return [向量列表, [text, outputs]]
                except Exception as e:
                    Module.写入日志(f"[文本生成向量] 使用本地模型生成向量出现错误, 跳过该向量生成: {e}, {text}", info_level=2)
                    return [None, [text, outputs]]
        else:
            while 重试次数 < Config.EMB_MAX_RETRY:
                try:
                    请求结果 = requests.post(
                        url=Config.EMB_API_URL,
                        headers={"Content-Type": "application/json","Authorization": f"Bearer {Config.EMB_API_KEY}"},
                        json={"input": text,"model": Config.EMB_MODEL},
                    ).json()
                    向量列表 = []
                    for index in range(len(text)):
                        向量列表.append(请求结果['data'][index]['embedding'])
                    向量列表 = np.array(向量列表).astype(np.float32)
                    return [向量列表, [text, outputs]]
                except Exception as e:
                    重试次数 += 1
                    if 重试次数 >= Config.EMB_MAX_RETRY:
                        Module.写入日志(f"[文本生成向量] 请求生成向量出现错误, 达到重试上限, 跳过该向量生成: {e}, {text}", info_level=3)
                        return [None, [text, outputs]]
                    else:
                        Module.写入日志(f"[文本生成向量] 请求生成向量出现错误, 正在重试...: {e}, {text}", info_level=2)
    def 并行生成向量(texts: list,) -> list:
        if not Config.EMB_API_URL and Config.EMB_MODEL:
            try:
                global 嵌入模型
                with Translator.线程锁:
                    for _ in tqdm(range(1), desc="加载模型"):
                        from sentence_transformers import SentenceTransformer
                        model_kwargs = {}
                        if Config.EMB_MODEL_ACC_MODE == "float64":
                            model_kwargs["dtype"] = "float64"
                        elif Config.EMB_MODEL_ACC_MODE == "float32":
                            model_kwargs["dtype"] = "float32"
                        elif Config.EMB_MODEL_ACC_MODE == "float16":
                            model_kwargs["dtype"] = "float16"
                        elif Config.EMB_MODEL_ACC_MODE == "bfloat16":
                            model_kwargs["dtype"] = "bfloat16"
                        if Config.EMB_MODEL_ACC_MODE == "onnx":
                            嵌入模型 = SentenceTransformer(
                                Config.EMB_MODEL,
                                trust_remote_code=True,
                                backend="onnx",
                            )
                        else:
                            嵌入模型 = SentenceTransformer(
                                Config.EMB_MODEL,
                                trust_remote_code=True,
                                model_kwargs=model_kwargs
                            )
                        Module.写入日志(f" 从 HuggingFace仓库 加载嵌入模型成功: {Config.EMB_MODEL}", info_level=0)
            except Exception as e:
                Module.写入日志(f" 从 HuggingFace仓库 加载嵌入模型失败: {e}", info_level=3)
                raise e
        if texts:
            最大字符数 = Config.EMB_MAX_TOKENS * Config.EMB_TOKENSTOTEXT_RATIO
            分组结果 = []
            当前组 = []
            当前总长 = 0.0
            for index in texts:
                首字符串 = index[0]
                长度 = len(首字符串)
                if 当前总长 + 长度 > 最大字符数:
                    分组结果.append(当前组)
                    当前组 = []
                    当前总长 = 0.0
                当前组.append(index)
                当前总长 += 长度
            if 当前组:
                分组结果.append(当前组)
            待处理文本列表原文 = [[item[0] for item in group] for group in 分组结果]
            待处理文本列表额外输出 = [[item[1] for item in group] for group in 分组结果]
            返回内容向量 = []
            with ThreadPoolExecutor(max_workers=Config.EMB_MAX_WORKERS) as 执行器:
                未来任务映射 = {
                    执行器.submit(
                        Translator.文本生成向量,
                        text=原文组,
                        outputs=额外输出
                    ): 原文组
                    for 原文组, 额外输出 in zip(待处理文本列表原文, 待处理文本列表额外输出)
                }
                for 单个任务 in tqdm(as_completed(未来任务映射), total=len(未来任务映射), desc="生成向量"):
                    返回内容向量.append(单个任务.result())
        if 返回内容向量:
            合并向量 = []
            合并请求文本 = []
            合并额外返回 = []
            for 结果 in 返回内容向量:
                if isinstance(结果[0], np.ndarray):
                    合并向量.extend(结果[0])
                    合并请求文本.extend(结果[1][0])
                    合并额外返回.extend(结果[1][1])
            return [np.array(合并向量).astype(np.float32), [合并请求文本, 合并额外返回]]
        Module.写入日志(f"[并行生成向量] 未生成任何向量：{texts}", info_level=3)

    def 参考词预处理(texts: list = None,) -> tuple[np.ndarray, list]:
        检索词 = []
        pkl文件内容 = []
        待处理文本 = []
        file_path = Config.VEC_FILE_PATH
        file_name = Config.VEC_FILE_NAME
        整数量化类型 = Config.VEC_INT_DTYPE
        浮点量化类型 = Config.VEC_FLOAT_DTYPE
        if texts:
            if Path(f"{file_path}/{file_name}.pkl").is_file():
                with open(f"{file_path}/{file_name}.pkl", "rb") as f:
                    pkl文件内容.extend(pickle.load(f))
                    for index in pkl文件内容:
                        检索词.append(index[0])
            检索词_set = set(检索词)
            待处理文本 = [index for index in texts if index[0] not in 检索词_set]
        if 待处理文本 and Config.EMB_MODEL:
            返回内容向量 = Translator.并行生成向量(待处理文本)
            向量结果列表 = 返回内容向量[0]
            Module.写入日志(f"[参考词预处理] 向量范围{(向量结果列表.min(), 向量结果列表.max())}", info_level=4)
            文本结果列表 = [[返回内容向量[1][0][i], 返回内容向量[1][1][i]] for i in range(len(返回内容向量[1][0]))]
            for _ in tqdm(range(1), desc="存储向量"):
                量化结果 = Quantization.编码向量(向量结果列表)
                if Config.VEC_QUANTIZATION in 整数量化类型:
                    Int8数据, 块缩放, 原始形状 = 量化结果
                    if Path(f"{file_path}/{file_name}.npz").is_file():
                        向量文件 = np.load(f"{file_path}/{file_name}.npz", allow_pickle=True)
                        向量文件 = [向量文件["向量"], 向量文件["块缩放"], 向量文件["形状"]]
                        Int8数据向量文件 = np.concatenate((Int8数据向量文件, Int8数据), axis=0)
                        块缩放向量文件 = np.concatenate((块缩放向量文件, 块缩放), axis=0)
                        最新形状 = (np.prod(原始形状) + np.prod(向量结果列表.shape),)
                        np.savez_compressed(f"{file_path}/{file_name}.npz", 向量=Int8数据向量文件, 块缩放=块缩放向量文件, 形状=最新形状)
                    else:
                        np.savez_compressed(f"{file_path}/{file_name}.npz", 向量=Int8数据, 块缩放=块缩放, 形状=原始形状)
                        向量文件 = [Int8数据, 块缩放, 原始形状]
                elif Config.VEC_QUANTIZATION in 浮点量化类型:
                    if Path(f"{file_path}/{file_name}.npz").is_file():
                        向量文件 = np.load(f"{file_path}/{file_name}.npz", allow_pickle=True)
                        向量文件 = np.concatenate((向量文件, 量化结果), axis=0)
                        np.savez_compressed(f"{file_path}/{file_name}.npz", 向量=向量文件)
                    else:
                        np.savez_compressed(f"{file_path}/{file_name}.npz", 向量=量化结果)
                        向量文件 = np.array(量化结果).astype(np.float32)

                if Path(f"{file_path}/{file_name}.pkl").is_file():
                    with open(f"{file_path}/{file_name}.pkl", "rb") as f:
                        文本文件 = pickle.load(f)
                    文本文件.extend(文本结果列表)
                    with open(f"{file_path}/{file_name}.pkl", "wb") as f:
                        pickle.dump(文本文件, f)
                else:
                    with open(f"{file_path}/{file_name}.pkl", "wb") as f:
                        pickle.dump(文本结果列表, f)
                    文本文件 = 文本结果列表
        else:
            try:
                for _ in tqdm(range(1), desc="读取向量"):
                    if Config.VEC_QUANTIZATION in 整数量化类型:
                        with open(f"{file_path}/{file_name}.npz", "rb") as f:
                            向量文件 = np.load(f, allow_pickle=True)
                            向量文件 = [向量文件["向量"], 向量文件["块缩放"], 向量文件["形状"]]
                    elif Config.VEC_QUANTIZATION in 浮点量化类型:
                        with open(f"{file_path}/{file_name}.npz", "rb") as f:
                            向量文件 = np.load(f, allow_pickle=True)
                            向量文件 = 向量文件["向量"]
                    with open(f"{file_path}/{file_name}.pkl", "rb") as f:
                        文本文件 = pickle.load(f)
            except Exception:
                return False, False
        return 向量文件, 文本文件
    def 生成翻译(texts: list, other_input: str):
        额外内容 = f"\n{Config.LLM_SYSTEM_PROMPTEX1}({[index[1] for index in other_input]})"
        messages = []
        if Config.LLM_CONTEXTS:
            with Translator.线程锁:
                if Translator.上下文:
                    messages.extend(Translator.上下文[-Config.LLM_CONTEXTS_LENGTH*2:])
        请求文本长度 = len(texts)
        请求文本 = texts[0] if 请求文本长度 == 1 else str(texts)
        if Config.LLM_PROMPT_LOCATION == "user":
            messages.insert(0, {"role": "system", "content": (Config.LLM_SYSTEM_PROMPT + "" if 请求文本长度 == 1 else Config.LLM_SYSTEM_PROMPTEX2).replace('\n', '')})
            messages.append({"role": "user", "content": 请求文本 + 额外内容})
            Module.写入日志(f"[生成翻译] 构建大语言模型请求消息 System: {(Config.LLM_SYSTEM_PROMPT + "" if 请求文本长度 == 1 else Config.LLM_SYSTEM_PROMPTEX2).replace('\n', '')}\nUser: {请求文本 + 额外内容}", info_level=4)
        elif Config.LLM_PROMPT_LOCATION == "system":
            messages.insert(0, {"role": "system", "content": (Config.LLM_SYSTEM_PROMPT + "" if 请求文本长度 == 1 else Config.LLM_SYSTEM_PROMPTEX2).replace('\n', '') + 额外内容})
            messages.append({"role": "user", "content": 请求文本})
            Module.写入日志(f"[生成翻译] 构建大语言模型请求消息 System: {(Config.LLM_SYSTEM_PROMPT + "" if 请求文本长度 == 1 else Config.LLM_SYSTEM_PROMPTEX2).replace('\n', '') + 额外内容}\nUser: {请求文本}", info_level=4)
        json = {
            "model": Config.LLM_MODEL,
            "messages": messages,
            "top_p": Config.LLM_TOP_P,
            "top_k": Config.LLM_TOP_K,
            "temperature": Config.LLM_TEMP,
            "stream": False,
        }
        请求次数 = 0
        while 请求次数 < Config.LLM_MAX_RETRY:
            请求结果 = requests.post(
                url=Config.LLM_API_URL,
                headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {Config.LLM_API_KEY}"
                },
                json=json
            ).json()
            try:
                请求结果 = 请求结果["choices"][0]["message"]["content"]
                添加上下文结果 = 请求结果
                请求结果 = re.sub(r'<think>.*?</think>\s*', '', 请求结果, flags=re.DOTALL)
                返回的请求结果 = [请求结果] if 请求文本长度 == 1 else ast.literal_eval(请求结果)
                返回结果 = []
                for index in range(len(texts)):
                    返回结果.append([other_input[index][0], texts[index], 返回的请求结果[index]])
                if Config.LLM_CONTEXTS:
                    with Translator.线程锁:
                        if Config.LLM_PROMPT_LOCATION == "user":
                            Translator.上下文.append({"role": "user", "content": 请求文本 + 额外内容})
                        elif Config.LLM_PROMPT_LOCATION == "system":
                            Translator.上下文.append({"role": "user", "content": 请求文本 })
                        Translator.上下文.append({"role": "assistant", "content": 添加上下文结果})
                return 返回结果
            except Exception as e:
                返回结果 = [[other_input[index][0], texts[index], texts[index]] for index in range(len(texts))]
                请求次数 += 1
                if 请求次数 >= Config.LLM_MAX_RETRY:
                    Module.写入日志(f"[生成翻译] 解析大语言模型翻译结果出现错误, 达到重试上限, 跳过该词条: {e}, {请求结果}", info_level=3)
                    return 返回结果
                else:
                    Module.写入日志(f"[生成翻译] 解析大语言模型翻译结果出现错误, 正在重试...: {e}, {请求结果}", info_level=2)
    def 构建索引(向量文件):
        向量文件 = 向量文件.get() if Config.GPU_ACC else 向量文件
        if Config.INDEX_SQ == "Q4":
            量化类型 = faiss.ScalarQuantizer.QT_4bit
        elif Config.INDEX_SQ == "Q6":
            量化类型 = faiss.ScalarQuantizer.QT_6bit
        elif Config.INDEX_SQ == "Q8":
            量化类型 = faiss.ScalarQuantizer.QT_8bit
        elif Config.INDEX_SQ == "F16":
            量化类型 = faiss.ScalarQuantizer.QT_fp16
        elif Config.INDEX_SQ == "BF16":
            量化类型 = faiss.ScalarQuantizer.QT_bf16
        if Config.INDEX_MODE == "HNSWSQ":
            向量索引 = faiss.IndexHNSWSQ(向量文件.shape[1], 量化类型, Config.INDEX_HNSW_M)
            向量索引.hnsw.efConstruction = Config.INDEX_HNSW_CONSTRUCTION
            向量索引.hnsw.efSearch = Config.INDEX_HNSW_SEARCH
            for _ in tqdm(range(1), desc="训练索引"):
                向量索引.train(向量文件)
            for _ in tqdm(range(1), desc="构建索引"):
                向量索引.add(向量文件)
        elif Config.INDEX_MODE == "RefineFlat":
            向量索引 = faiss.IndexRefineFlat(faiss.IndexFlatL2(向量文件.shape[1]))
            向量索引.k_factor = Config.INDEX_REFINEFLAT_K_FACTOR
            for _ in tqdm(range(1), desc="构建索引"):
                向量索引.add(向量文件)
        return 向量索引
    def 缓存索引(向量文件, 文本文件):
        索引配置 = [Config.INDEX_MODE, Config.INDEX_SQ, Config.INDEX_HNSW_CONSTRUCTION, Config.INDEX_HNSW_SEARCH, Config.INDEX_HNSW_M, Config.INDEX_REFINEFLAT_K_FACTOR]
        参考词哈希 = hashlib.sha3_256(pickle.dumps((向量文件, 文本文件, 索引配置))).hexdigest()
        emb_file_path = Config.VEC_FILE_PATH
        emb_file_name = Config.VEC_FILE_NAME
        if Path(f"{emb_file_path}/{emb_file_name}.faiss-sha3").is_file():
            with open(f"{emb_file_path}/{emb_file_name}.faiss-sha3", "r") as f:
                参考词哈希文件 = f.read()
            if 参考词哈希文件 == 参考词哈希:
                for _ in tqdm(range(1), desc="读取索引"):
                    向量索引 = faiss.read_index(f"{emb_file_path}/{emb_file_name}.faiss")
            else:
                向量索引 = Translator.构建索引(向量文件)
                for _ in tqdm(range(1), desc="存储索引"):
                    with open(f"{emb_file_path}/{emb_file_name}.faiss-sha3", "w+") as f:
                        f.write(参考词哈希)
                    faiss.write_index(向量索引, f"{emb_file_path}/{emb_file_name}.faiss")
        else:
            向量索引 = Translator.构建索引(向量文件)
            for _ in tqdm(range(1), desc="存储索引"):
                with open(f"{emb_file_path}/{emb_file_name}.faiss-sha3", "w+") as f:
                    f.write(参考词哈希)
                faiss.write_index(向量索引, f"{emb_file_path}/{emb_file_name}.faiss")
        return 向量索引
    def 翻译语言列表(texts: list,) -> list:
        输入列表 = []
        返回列表 = []
        if texts == []:
            return []
        for index in texts:
            try:
                输入列表.append([index[1], index[0]])
            except Exception as e:
                Module.写入日志(f"[翻译语言列表] 解析传入时出现错误, 跳过该词条: {e}, {index}", info_level=2)
                pass
        try:
            向量文件, 文本文件 = Translator.参考词预处理()
            向量文件 = Quantization.解码向量(向量文件)
            Module.写入日志(f"[翻译语言列表] 向量形状: {向量文件.shape}", info_level=4)
            if 文本文件:
                向量索引 = Translator.缓存索引(向量文件, 文本文件)
                输入列表 = Translator.并行生成向量(输入列表)
                向量列表 = np.array(输入列表[0]).astype(np.float32)
                向量列表 = 向量列表.get() if Config.GPU_ACC else 向量列表
                for _ in tqdm(range(1), desc="近邻索引"):
                    索引结果矩阵 = 向量索引.search(向量列表, Config.INDEX_K)[1]
                返回请求内容 = []
                返回其他内容 = []
                文本索引 = {index2[0]: index for index, index2 in enumerate(文本文件)}
                原文文本文件 = [index[0] for index in 文本文件]
                for index in range(len(向量列表)):
                    请求内容 = 输入列表[1][0][index]
                    键 = 输入列表[1][1][index]
                    其他内容 = [键, f"键值:{键}|参考内容:"]
                    for index2 in 索引结果矩阵[index]:
                        原文 = 原文文本文件[index2]
                        if 原文 in 文本索引:
                            其他内容[1] += f"{文本文件[文本索引[原文]]}|"
                    返回请求内容.append(请求内容)
                    返回其他内容.append(其他内容)
            else:
                返回请求内容 = [row[1] for row in texts]
                返回其他内容 = [[row[0], f"键值:{row[0]}"] for row in texts]
            llm_max_batch = Config.LLM_MAX_BATCH
            其他列表 = [返回其他内容[i:i + llm_max_batch] for i in range(0, len(返回其他内容), llm_max_batch)]
            请求列表 = [返回请求内容[i:i + llm_max_batch] for i in range(0, len(返回请求内容), llm_max_batch)]
            
            with ThreadPoolExecutor(max_workers=Config.LLM_MAX_WORKERS) as 执行器:
                未来任务映射 = {
                    执行器.submit(
                        Translator.生成翻译,
                        texts = index,
                        other_input = index2,
                    ): index
                    for index, index2 in zip(请求列表, 其他列表)
                }
                for 单个任务 in tqdm(as_completed(未来任务映射), total=len(未来任务映射), desc="生成翻译"):
                    返回列表.extend(单个任务.result())
            参考字典 = {item[0] for item in texts}
            返回列表 = [[a, c] for a, b, c in 返回列表 if a in 参考字典]
        except Exception as e:
            Module.写入日志(f"[翻译语言列表] 翻译时出现错误: {e}, {texts}", info_level=3)
            raise e
        return 返回列表
    def 翻译语言文件(file0: str,  file1: str = "", output_path: str = ".", export_inspection: bool = False):
        未翻译列表 = []
        去翻译列表 = []
        输出列表 = []
        翻译输出列表 = []
        可翻译源文件, 源文件, 参考文件, 压缩路径, 输出扩展名, file2 = Module.读取资源文件(file0, file1)
        if 参考文件:
            参考字典 = {}
            for item in 参考文件:
                try:
                    参考字典[item[0]] = item[1]
                except Exception as e:
                    Module.写入日志(f"[翻译语言文件] 解析参考文件出现错误: {e}, {item}", info_level=2)
                    pass
            for index1 in 可翻译源文件:
                key = index1[0]
                if key in 参考字典:
                    去翻译列表.append([key, 参考字典[key]])
                else:
                    未翻译列表.append(index1)
        else:
            未翻译列表 = 可翻译源文件.copy()
        if Config.TRANSLATOR_CACHE_READ:
            翻译缓存, 匹配字典 = Module.翻译缓存()
            缓存长度 = len(未翻译列表)
            命中缓存 = []
            成功缓存 = 0
            for index in tqdm(未翻译列表, desc="查找缓存"):
                if index[1] in 匹配字典:
                    命中缓存.append(index)
                    去翻译列表.append([index[1], 翻译缓存[index[1]]])
                    成功缓存 += 1 
                else: pass
            for index in tqdm(命中缓存, desc="运用缓存"):
                未翻译列表.remove(index)
            if 成功缓存 == 0:
                Module.写入日志(f"[翻译语言文件] 缓存命中率: 0.00%, 缓存长度: {缓存长度}", info_level=0)
            else:
                Module.写入日志(f"[翻译语言文件] 缓存命中率: {成功缓存 / 缓存长度:.2%}, 缓存长度: {缓存长度}", info_level=0)
        翻译列表 = Translator.翻译语言列表(未翻译列表)
        if Config.TRANSLATOR_CACHE_WRITE:
            Module.翻译缓存([[未翻译列表[index][1], 翻译列表[index][1]] for index in range(len(未翻译列表))])
        if export_inspection:
            for index in tqdm(range(len(未翻译列表)), desc="正在编码"):
                行数据 = [{翻译列表[index][0]: 翻译列表[index][1]}, 未翻译列表[index][1]]
                输出列表.append(repr(行数据))
            with open(str(Path(f"{output_path}/{Config.LANGUAGE_OUTPUT}.translatorlang")), 'w+', encoding='utf-8') as f:
                f.write("\n".join(输出列表))
            Module.写入日志(f"[翻译语言文件] 翻译完成, 导出路径: {str(Path(f"{output_path}/{Config.LANGUAGE_OUTPUT}.translatorlang"))}", info_level=0)
        else:
            所有翻译结果 = 翻译列表 + 去翻译列表
            for index in 源文件:
                if index.strip().startswith(('#', '//')):
                    翻译输出列表.append(index)
                else:
                    索引成功 = False
                    for index1 in 所有翻译结果:
                        if index.split('=', 1)[0] == index1[0]:
                            翻译输出列表.append(f"{index1[0]}={index1[1]}")
                            索引成功 = True
                            break
                    if not 索引成功:
                        翻译输出列表.append(index)
            if 压缩路径:
                输出路径 = f"{Path(压缩路径).parent}/{Config.LANGUAGE_OUTPUT}{输出扩展名}"
                Module.保存语言文件(输出路径, 翻译输出列表)
                压缩文件夹Path = Path(压缩路径).parent.parent.parent
                if file2[0] == False:
                    压缩文件夹Path = 压缩文件夹Path.parent
                    with open(f"{str(压缩文件夹Path)}/pack.mcmeta", "w+", encoding="utf-8") as f:
                        f.write(json.dumps({"pack": {"description": f"{Path(file0).stem}的{Config.LANGUAGE_OUTPUT}语言资源包, 由 海盐青茫 制作, 由 {Config.LLM_MODEL} 翻译","pack_format": 9999,"supported_formats": [0, 9999],"min_format": 0,"max_format": 9999}}, ensure_ascii=False, indent=4))
                压缩文件夹 = str(压缩文件夹Path)
                with zipfile.ZipFile(f"{output_path}/{Path(file0).stem}-{Config.LANGUAGE_OUTPUT}.zip", 'w', zipfile.ZIP_DEFLATED) as f:
                    for 压缩文件 in 压缩文件夹Path.rglob('*'):
                        if 压缩文件.is_file():
                            f.write(压缩文件, arcname=压缩文件.relative_to(压缩文件夹))
                Module.写入日志(f"[翻译语言文件] 翻译完成, 导出路径: {output_path}/{Path(file0).stem}-{Config.LANGUAGE_OUTPUT}.zip", info_level=0)
            else:
                if not Path(output_path).suffix:
                    output_path = str(Path(f"{output_path}/{Config.LANGUAGE_OUTPUT}{输出扩展名}"))
                Module.保存语言文件(output_path, 翻译输出列表)
                Module.写入日志(f"[翻译语言文件] 翻译完成, 导出路径: {output_path}", info_level=0)
    def 导入参考词(path: str):
        def 打开文件(file: str):
            with open(file, "r", encoding="utf-8") as f:
                if Path(file).suffix == ".lang":
                    文件 = f.read().splitlines()
                elif Path(file).suffix == ".json":
                    文件 = "[" + ",".join(f"{k}={v}" for k, v in json.load(f).items()) + "]"
                文件 = [line.split('=', 1)   for line in 文件   if (stripped := line.strip()) and not stripped.startswith('#') and not stripped.startswith('//')]
            f.close()
            return 文件
        target_language = Config.LANGUAGE_OUTPUT
        original_language = Config.LANGUAGE_INPUT
        待处理列表 = []
        for index in ["*.jar", "*.zip", "*.pkl"]:
            for 文件路径 in list(Path(path).rglob(index)):
                文件路径 = str(文件路径)
                缓存路径 = f"{Config.PATH_CACHE}/{Module.随机16进制字符串(4)}"
                if Path(文件路径).suffix == ".pkl":
                    with open(文件路径, "rb") as f:
                        待处理列表.extend(pickle.load(f))
                else:
                    处理列表 = []
                    文件列表 = Module.读取压缩文件(文件路径, 缓存路径, original_language, target_language)
                    if not any(isinstance(item, list) and len(item) > 0 and item[0] == original_language for item in 文件列表[1:]): continue
                    if not any(isinstance(item, list) and len(item) > 0 and item[0] == target_language for item in 文件列表[1:]): continue
                    for index1 in 文件列表[1:]:
                        if index1[0] == original_language:
                            原文文件 = index1[1]
                        if index1[0] == target_language:
                            目标文件 = index1[1]
                    原文文件, 目标文件 = 打开文件(原文文件), 打开文件(目标文件)
                    目标映射 = {}
                    for item in 目标文件:
                        if len(item) >= 2:
                            目标映射[item[0]] = item[1]
                    处理列表.extend([[原文[1], 目标映射[原文[0]]] for 原文 in 原文文件 if 原文[0] in 目标映射])
                    待处理列表 += 处理列表
        Translator.参考词预处理(待处理列表)
    def 翻译FTB任务(path: str):
        翻译列表 = []
        snbt文件 = [str(index) for index in Path(path).rglob("*.snbt")]
        with mp.Pool(processes=int(mp.cpu_count() / 2 if mp.cpu_count() / 2 > 1 else 1)) as 解释器:
            任务结果 = 解释器.imap(Module.读取单个FTBQ_Snbt文件, snbt文件)
            for 单个任务 in tqdm(任务结果, total=len(snbt文件), desc="读取文件"):
                翻译列表.extend(单个任务)
        翻译列表 = Translator.翻译语言列表(翻译列表)
        分组 = defaultdict(list)
        for item in 翻译列表:
            key = item[0][0]
            分组[key].append(item)
        翻译列表 = [分组[k] for k in sorted(分组.keys())]
        with mp.Pool(processes=int(mp.cpu_count() / 2 if mp.cpu_count() / 2 > 1 else 1)) as 解释器:
            任务结果 = 解释器.imap(partial(Module.应用FTBQ翻译, mode=("H" if os.path.isdir(os.path.join(path, "quests")) else "L")), 翻译列表)
            for 单个任务 in tqdm(任务结果, total=len(翻译列表), desc="应用翻译"): pass
    def 翻译BQ任务(path: str):
        翻译列表 = []
        nbt文件 = [str(index) for index in Path(path).rglob("*.json")]
        with mp.Pool(processes=int(mp.cpu_count() / 2 if mp.cpu_count() / 2 > 1 else 1)) as 解释器:
            任务结果 = 解释器.imap(Module.读取单个BQ_Json文件, nbt文件)
            for 单个任务 in tqdm(任务结果, total=len(nbt文件), desc="读取文件"):
                翻译列表.extend(单个任务)
        翻译列表 = Translator.翻译语言列表(翻译列表)
        分组 = defaultdict(list)
        for item in 翻译列表:
            key = item[0][0]
            分组[key].append(item)
        翻译列表 = [分组[k] for k in sorted(分组.keys())]
        with mp.Pool(processes=int(mp.cpu_count() / 2 if mp.cpu_count() / 2 > 1 else 1)) as 解释器:
            任务结果 = 解释器.imap(partial(Module.应用BQ翻译), 翻译列表)
            for 单个任务 in tqdm(任务结果, total=len(翻译列表), desc="应用翻译"): pass
    def 导入DictMini参考词(file: str, mode: str = "dense"):
        待处理列表 = []
        for _ in tqdm(range(1), desc="读取文件"):
            with open(file, "rb") as f:
                Dict文件 = json.load(f)
        if mode == "dense":
            for index in tqdm(Dict文件, desc="处理文件"):
                待处理列表.append([index, ", ".join(Dict文件[index])])
        elif mode == "sparse":
            for index in tqdm(Dict文件, desc="处理文件"):
                for index1 in Dict文件[index]:
                    待处理列表.append([index, index1])
        Translator.参考词预处理(待处理列表)
class Tool:
    def DictMini转换数据集(file: str, mode: str, output_file: str = "dataset.jsonl"):
        待处理列表 = []
        for _ in tqdm(range(1), desc="读取文件"):
            with open(file, "rb") as f:
                Dict文件 = json.load(f)
        for index in tqdm(Dict文件, desc="处理文件"):
            for index2 in Dict文件[index]:
                待处理列表.append([index, index2])
        导出列表 = []
        for index in tqdm(待处理列表, desc="正在编码"):
            if mode == "ChatML":
                导出列表.append({"messages": [{"role": "system", "content": f"将下列文本翻译为{Config.LANGUAGE_OUTPUT}语言"}, {"role": "user", "content": index[0]}, {"role": "assistant", "content": index[1]}]})
            elif mode == "Alpaca":
                导出列表.append({"instruction": f"翻译为{Config.LANGUAGE_OUTPUT}语言", "input": index[0], "output": index[1], "system": f"将下列文本翻译为{Config.LANGUAGE_OUTPUT}语言"})
        with open(output_file, 'w+', encoding='utf-8') as f:
            f.write('\n'.join(json.dumps(item, ensure_ascii=False, separators=(',', ':')) for item in tqdm(导出列表, desc="正在序列化")))
    def 分离语言文件更新(file0: str, file1: str = "", output_path: str = ".", mode: str = "none"):
        缺失列表 = []
        输出列表 = []
        文件0, _, 文件1, _, 输出扩展名, _ = Module.读取资源文件(file0, file1)
        if 文件1:
            参考字典 = {}
            for item in 文件1:
                try:
                    参考字典[item[0]] = item[1]
                except Exception as e:
                    Module.写入日志(f"[分离语言文件更新] 解析参考文件出现错误: {e}, {item}", info_level=2)
                    pass
            for index1 in 文件0:
                key = index1[0]
                if not key in 参考字典:
                    缺失列表.append(index1)
        else:
            缺失列表 = 文件0.copy()
        if not Path(output_path).suffix:
            导出路径 = str(Path(f"{output_path}/{Config.LANGUAGE_OUTPUT}{输出扩展名}"))
        else:
            导出路径 = str(Path(output_path))
        if mode == "none":
            Module.保存语言文件(导出路径, [f"{index[0]}={index[1]}" for index in 缺失列表])
        elif mode == "extra":
            输入列表 = []
            for index in 缺失列表:
                try:
                    输入列表.append([index[1], index[0]])
                except Exception as e:
                    Module.写入日志(f"[分离语言文件更新] 解析传入时出现错误, 跳过该词条: {e}, {index}", info_level=2)
                    pass
            向量文件, 文本文件 = Translator.参考词预处理()
            向量文件 = Quantization.解码向量(向量文件)
            Module.写入日志(f"[分离语言文件更新] 向量形状: {向量文件.shape}", info_level=4)
            if 文本文件:
                向量索引 = Translator.缓存索引(向量文件, 文本文件)
                输入列表 = Translator.并行生成向量(输入列表)
                向量列表 = np.array(输入列表[0]).astype(np.float32)
                向量列表 = 向量列表.get() if Config.GPU_ACC else 向量列表
                for _ in tqdm(range(1), desc="近邻索引"):
                    索引结果矩阵 = 向量索引.search(向量列表, Config.INDEX_K)[1]
                返回请求内容 = []
                返回其他内容 = []
                文本索引 = {index2[0]: index for index, index2 in enumerate(文本文件)}
                原文文本文件 = [index[0] for index in 文本文件]
                for index in range(len(向量列表)):
                    其他内容 = ""
                    for index2 in 索引结果矩阵[index]:
                        原文 = 原文文本文件[index2]
                        if 原文 in 文本索引:
                            其他内容 += (f"{文本文件[文本索引[原文]]}|")
                    返回请求内容.append({输入列表[1][1][index]: 输入列表[1][0][index]})
                    返回其他内容.append(f"{其他内容}")
            for index in tqdm(range(len(返回请求内容)), desc="正在编码"):
                行数据 = [返回请求内容[index], 返回其他内容[index]]
                输出列表.append(repr(行数据))
            with open(str(Path(f"{output_path}/{Config.LANGUAGE_OUTPUT}.translatorlang")), 'w+', encoding='utf-8') as f:
                f.write("\n".join(输出列表))
            
    def 合并语言文件更新(file0: str, notlang_file: str, file1: str = "", output_path: str = "."):
        合并列表 = []
        输出列表 = []
        缺失列表 = []
        文件0, 文件0源文件, 文件1, 压缩路径, 输出扩展名, file2 = Module.读取资源文件(file0, file1)
        if 文件1:
            参考字典 = {}
            for item in 文件1:
                try:
                    参考字典[item[0]] = item[1]
                except Exception as e:
                    Module.写入日志(f"[合并语言文件更新] 解析参考文件出现错误: {e}, {item}", info_level=2)
                    pass
            for index1 in 文件0:
                key = index1[0]
                if key in 参考字典:
                    合并列表.append(index1)
        else:
            合并列表 = 文件0.copy()
        if Path(notlang_file).suffix == ".translatorlang":
            with open(notlang_file, 'r', encoding='utf-8') as f:
                缺失列表文件 = f.read().splitlines()
            for index in 缺失列表文件:
                index = ast.literal_eval(index)[0]
                for index1, index2 in index.items():
                    缺失列表.append([index1, index2])
        else:
            缺失列表 = Module.读取语言文件(notlang_file)[0]
        合并列表 = 合并列表 + 缺失列表
        for index in 文件0源文件:
            if index.strip().startswith(('#', '//')):
                输出列表.append(index)
            else:
                索引成功 = False
                for index1 in 合并列表:
                    if index.split('=', 1)[0] == index1[0]:
                        输出列表.append(f"{index1[0]}={index1[1]}")
                        索引成功 = True
                        break
                if not 索引成功:
                    输出列表.append(index)
        if 压缩路径:
            输出路径 = f"{Path(压缩路径).parent}/{Config.LANGUAGE_OUTPUT}{输出扩展名}"
            Module.保存语言文件(输出路径, 输出列表)
            压缩文件夹Path = Path(压缩路径).parent.parent.parent
            if file2[0] == False:
                压缩文件夹Path = 压缩文件夹Path.parent
                with open(f"{str(压缩文件夹Path)}/pack.mcmeta", "w+", encoding="utf-8") as f:
                    f.write(json.dumps({"pack": {"description": f"{Path(file0).stem}的{Config.LANGUAGE_OUTPUT}语言资源包","pack_format": 9999,"supported_formats": [0, 9999],"min_format": 0,"max_format": 9999}}, ensure_ascii=False, indent=4))
            压缩文件夹 = str(压缩文件夹Path)
            with zipfile.ZipFile(f"{output_path}/{Path(file0).stem}-{Config.LANGUAGE_OUTPUT}.zip", 'w', zipfile.ZIP_DEFLATED) as f:
                for 压缩文件 in 压缩文件夹Path.rglob('*'):
                    if 压缩文件.is_file():
                        f.write(压缩文件, arcname=压缩文件.relative_to(压缩文件夹))
        else:
            输出路径 = str(f"{output_path}/{Config.LANGUAGE_OUTPUT}{输出扩展名}")
            Module.保存语言文件(输出路径, 输出列表)