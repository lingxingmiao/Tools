import re
import os
import time
import json
import random
import pickle
import zipfile
from pathlib import Path

from pyhocon import ConfigFactory, HOCONConverter

from tqdm import tqdm

from TranslatorConfig import Config

class Module:
    def 写入日志(text: str, info_level: int = 0):
        Path(Config.LOGS_FILE_PATH).mkdir(parents=True, exist_ok=True)
        with open(f"{Config.LOGS_FILE_PATH}/{Config.LOGS_FILE_NAME}", "a+", encoding="utf-8") as f:
            时间 = time.strftime("[%Y-%m-%d %H:%M:%S]", time.localtime())
            if info_level == 0:
                f.write(f"{时间}[INFO]{text}\n")
            elif info_level == 1:
                f.write(f"{时间}[WARNING]{text}\n")
            elif info_level == 2:
                f.write(f"{时间}[ERROR]{text}\n")
            elif info_level == 3:
                f.write(f"{时间}[FATAL]{text}\n")
            elif info_level == 4 and Config.DEBUG_MODE:
                f.write(f"{时间}[DEBUG]{text}\n")
    def 读取单个FTBQ_Snbt文件(index: str):
        文本列表 = []
        SNBT文件 = ConfigFactory.parse_file(index)
        if "description" in SNBT文件:
            if isinstance(SNBT文件["description"], str):
                文本列表.append([[index, ["description"]], SNBT文件["description"]])
            elif isinstance(SNBT文件["description"], list):
                for index2q, index2 in enumerate(SNBT文件["description"]):
                    文本列表.append([[index, ["description", index2q]], index2])
        if "rewards" in SNBT文件:
            for index2q, index2 in enumerate(SNBT文件["rewards"]):
                if "title" in index2:
                    文本列表.append([[index, ["rewards", index2q], ["title"]], index2["title"]])
        if "subtitle" in SNBT文件:
            文本列表.append([[index, ["subtitle"]], SNBT文件["subtitle"]])
        if "title" in SNBT文件:
            文本列表.append([[index, ["title"]], SNBT文件["title"]])
        if "tasks" in SNBT文件:
            for index1q, index1 in enumerate(SNBT文件["tasks"]):
                if "items" in index1:
                    for index2q, index2 in enumerate(index1["items"]):
                        if "tag" in index2:
                            if "pages" in index2["tag"]:
                                for index3q, index3 in enumerate(index2["tag"]["pages"]):
                                    文本列表.append([[index, ["tasks", index1q], ["items", index2q], ["tag"], ["pages", index3q]], index3])
                            if "title" in index2["tag"]:
                                文本列表.append([[index, ["tasks", index1q], ["items", index2q], ["tag"], ["title"]], index3])
                            if "display" in index2["tag"]:
                                if "Lore" in index2["tag"]["display"]:
                                    for index3q, index3 in enumerate(index2["tag"]["display"]["Lore"]):
                                        文本列表.append([[index, ["tasks", index1q], ["items", index2q], ["tag", "display"], ["Lore", index3q]], index3])
                                if "Name" in index2["tag"]["display"]:
                                    文本列表.append([[index, ["tasks", index1q], ["items", index2q], ["tag", "display"], ["Name"]], index2["tag"]["display"]["Name"]])
                if "title" in index1:
                    文本列表.append([[index, ["tasks", index1q], ["title"]], index1["title"]])
        if "rewards" in SNBT文件:
            for index1q, index1 in enumerate(SNBT文件["rewards"]):
                if "item" in index1:
                    if isinstance(index1["item"], dict) and "tag" in index1["item"]:
                        if "pages" in index1["item"]["tag"]:
                            for index3q, index3 in enumerate(index1["item"]["tag"]["pages"]):
                                文本列表.append([[index, ["rewards", index1q], ["item", "tag"], ["pages", index3q]], index3])
                        if "title" in index1["item"]["tag"]:
                            文本列表.append([[index, ["rewards", index1q], ["item", "tag"], ["title"]], index3])
                        if "display" in index1["item"]["tag"]:
                            if "Lore" in index1["item"]["tag"]["display"]:
                                for index3q, index3 in enumerate(index1["item"]["tag"]["display"]["Lore"]):
                                    文本列表.append([[index, ["rewards", index1q], ["item", "tag", "display"], ["Lore", index3q]], index3])
                            if "Name" in index1["item"]["tag"]["display"]:
                                文本列表.append([[index, ["rewards", index1q], ["item", "tag", "display"], ["Name"]], index1["item"]["tag"]["display"]["Name"]])
                if "title" in index1:
                    文本列表.append([[index, ["rewards", index1q], ["title"]], index1["title"]])
        if "text" in SNBT文件:
            for index1q, index1 in enumerate(SNBT文件["text"]):
                文本列表.append([[index, ["text", index1q]], index1])
        if "quests" in SNBT文件:
            for index1q, index1 in enumerate(SNBT文件["quests"]):
                if "description" in index1:
                    for index2q, index2 in enumerate(index1["description"]):
                        文本列表.append([[index, ["quests", index1q], ["description", index2q]], index2])
                if "rewards" in index1:
                    for index2q, index2 in enumerate(index1["rewards"]):
                        if "title" in index2:
                            文本列表.append([[index, ["quests", index1q], ["rewards", index2q], ["title"]], index2["title"]])
                if "subtitle" in index1:
                    文本列表.append([[index, ["quests", index1q], ["subtitle"]], index1["subtitle"]])
                if "title" in index1:
                    文本列表.append([[index, ["quests", index1q], ["title"]], index1["title"]])
                if "tasks" in index1:
                    for index2q, index2 in enumerate(index1["tasks"]):
                        if "title" in index2:
                            文本列表.append([[index, ["quests", index1q], ["tasks", index2q], ["title"]], index2["title"]])
        if "chapter_groups" in SNBT文件:
            for index1q, index1 in enumerate(SNBT文件["chapter_groups"]):
                文本列表.append([[index, ["chapter_groups", index1q]], index["title"]])
        return 文本列表
    def 应用FTBQ翻译(index: list, mode: str):
        SNBT文件 = ConfigFactory.parse_file(index[0][0][0])
        for index1p, index1 in enumerate(index):
            层数 = len(index[index1p][0][1:])
            位置 = index1[0][1:]
            if 层数 == 1:
                if len(位置[0]) == 1:
                    SNBT文件[位置[0][0]] = index1[1]
                else:
                    列表 = SNBT文件[位置[0][0]]
                    列表[位置[0][1]] = index1[1]
                    SNBT文件[位置[0][0]] = 列表
            elif 层数 == 2:
                if len(位置[1]) == 1:
                    SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]] = index1[1]
                else:
                    列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]]
                    列表[位置[1][1]] = index1[1]
                    SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]] = 列表
            elif 层数 == 3:
                if not isinstance(位置[1][1], str):
                    if len(位置[2]) == 1:
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]] = index1[1]
                    else:
                        列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]]
                        列表[位置[2][1]] = index1[1]
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]] = 列表
                else:
                    if len(位置[1]) == 2:
                        if len(位置[2]) == 1:
                            SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]] = index1[1]
                        else:
                            列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]]
                            列表[位置[2][1]] = index1[1]
                            SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]] = 列表
                    elif len(位置[1]) == 3:
                        if len(位置[2]) == 1:
                            SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[1][2]][位置[2][0]] = index1[1]
                        else:
                            列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[1][2]][位置[2][0]]
                            列表[位置[2][1]] = index1[1]
                            SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[1][2]][位置[2][0]] = 列表
            elif 层数 == 4:
                if len(位置[2]) == 1:
                    if len(位置[3]) == 1:
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[3][0]] = index1[1]
                    elif len(位置[3]) == 2:
                        列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[3][0]]
                        列表[位置[3][1]] = index1[1]
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[3][0]] = 列表
                elif len(位置[2]) == 2:
                    if len(位置[3]) == 1:
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[2][1]][位置[3][0]] = index1[1]
                    elif len(位置[3]) == 2:
                        列表 = SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[2][1]][位置[3][0]]
                        列表[位置[3][1]] = index1[1]
                        SNBT文件[位置[0][0]][位置[0][1]][位置[1][0]][位置[1][1]][位置[2][0]][位置[2][1]][位置[3][0]] = 列表

        with open(index[0][0][0], "w", encoding="utf-8") as f:
            json文件 = HOCONConverter.to_json(SNBT文件, indent=4).splitlines()
            if mode ==  "H":
                去逗号json文件 = []
                for index in json文件:
                    if index.endswith(","):
                        index = index[:-1]
                    去逗号json文件.append(index)
                json文件 = 去逗号json文件
            for index1p, index1 in enumerate(json文件):
                index1 = re.sub(r'":\s*"([+-]?\d+\.?\d*[bdL])"',r'": \1',index1)
                #index1 = re.sub(r'"([^"]+)":', r'\1:', index1)
                index1 = re.sub(r'"([a-zA-Z_][a-zA-Z0-9_]*)":', r'\1:', index1)
                json文件[index1p] = index1
            f.write("\n".join(json文件))
    def 读取单个BQ_Json文件(index: str):
        文件列表 = []
        with open(index, "r", encoding="utf-8") as f:
            NBT文件 = json.load(f)
        if "properties:10" in NBT文件:
            if "betterquesting:10" in NBT文件["properties:10"]:
                if "name:8" in NBT文件["properties:10"]["betterquesting:10"]:
                    文件列表.append([[index, ["properties:10", "betterquesting:10"], ["name:8"]], NBT文件["properties:10"]["betterquesting:10"]["name:8"]])
                if "desc:8" in NBT文件["properties:10"]["betterquesting:10"]:
                    文件列表.append([[index, ["properties:10", "betterquesting:10"], ["desc:8"]], NBT文件["properties:10"]["betterquesting:10"]["desc:8"]])
        if "questDatabase:9" in NBT文件:
            for index1 in NBT文件["questDatabase:9"]:
                if "properties:10" in NBT文件["questDatabase:9"][index1]:
                    if "betterquesting:10" in NBT文件["questDatabase:9"][index1]["properties:10"]:
                        if "name:8" in NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]:
                            文件列表.append([[index, ["questDatabase:9", index1, "properties:10", "betterquesting:10"], ["name:8"]], NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]["name:8"]])
                        if "desc:8" in NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]:
                            文件列表.append([[index, ["questDatabase:9", index1, "properties:10", "betterquesting:10"], ["desc:8"]], NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]["desc:8"]])
        if "questLines:9" in NBT文件:
            for index1 in NBT文件["questLines:9"]:
                if "properties:10" in NBT文件["questLines:9"][index1]:
                    if "betterquesting:10" in NBT文件["questLines:9"][index1]["properties:10"]:
                        if "name:8" in NBT文件["questLines:9"][index1]["properties:10"]["betterquesting:10"]:
                            文件列表.append([[index, ["questLines:9", index1, "properties:10", "betterquesting:10"], ["name:8"]], NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]["name:8"]])
                        if "desc:8" in NBT文件["questLines:9"][index1]["properties:10"]["betterquesting:10"]:
                            文件列表.append([[index, ["questLines:9", index1, "properties:10", "betterquesting:10"], ["desc:8"]], NBT文件["questDatabase:9"][index1]["properties:10"]["betterquesting:10"]["desc:8"]])
        return 文件列表
    def 应用BQ翻译(index: list):
        with open(index[0][0][0], "r", encoding="utf-8") as f:
            NBT文件 = json.load(f)
        for index1 in index:
            位置 = index1[0][1:]
            if len(位置[0]) == 2:
                NBT文件[位置[0][0]][位置[0][1]][位置[1][0]] = index1[1]
            if len(位置[0]) == 4:
                NBT文件[位置[0][0]][位置[0][1]][位置[0][2]][位置[0][3]][位置[1][0]] = index1[1]
        with open(index[0][0][0], "w+", encoding="utf-8") as f:
            json.dump(NBT文件, f, ensure_ascii=False, indent=2)
    def 读取语言文件(file: str):
        with open(file, "r", encoding="utf-8") as f:
            if Path(file).suffix == ".lang":
                源文件 = f.read().splitlines()
            elif Path(file).suffix == ".json":
                Json文件 = json.load(f)
                源文件 = [f"{index}={Json文件[index]}" for index in Json文件]
            return [line.split('=', 1)   for line in 源文件   if (stripped := line.strip()) and not stripped.startswith('#') and not stripped.startswith('//')], 源文件
    def 保存语言文件(file: str, 保存列表: list):
        with open(file, "w+", encoding="utf-8") as f:
            if Path(file).suffix == ".lang":
                f.write("\n".join(保存列表))
            elif Path(file).suffix == ".json":
                保存列表 = [line for line in 保存列表   if line.strip()   and '=' in line   and not line.lstrip().startswith(('//', '#'))]
                json文件 = {line.split('=', 1)[0]: line.split('=', 1)[1] for line in 保存列表}
                f.write(json.dumps(json文件, ensure_ascii=False, indent=4))
    def 随机16进制字符串(length: int):
        return '-'.join([f'{random.randint(0, 0xFFFF):04X}' for _ in range(length)])
    def 读取压缩文件(file_path: str, cache_path: str, original_language: str, target_language: str):
        try:
            for _ in tqdm(range(1), desc="读取文件"): 
                with zipfile.ZipFile(file_path, 'r') as f:
                    可用文件列表 = [False]
                    文件列表 = f.namelist()
                    文件路径 = f"{cache_path}/{Module.随机16进制字符串(1)}_{Path(file_path).stem}"
                    if any(name.startswith("shaders") for name in 文件列表):
                        可用文件列表 = [True]
                        f.extractall(文件路径)
                    for index in [original_language, target_language]:
                        for index1 in 文件列表:
                            index1文件名 = os.path.splitext(index1.split('/')[-1])[0]
                            if index1文件名.lower() == index.lower():
                                f.extract(index1, path=文件路径)
                                可用文件列表.append([index, f"{文件路径}/{index1}"])
        except Exception as e:
            Module.写入日志(f"[读取压缩文件] 读取压缩文件出现错误: {e}", info_level=3)
            raise FileNotFoundError(e)
        return 可用文件列表
    def 读取资源文件(file0: str, file1: str):
        压缩路径 = ""
        文件1 = ""
        file2 = ""
        if Path(file0).suffix in [".zip", ".jar"]:
            缓存路径 = f"{Config.PATH_CACHE}/{Module.随机16进制字符串(4)}"
            file2 = Module.读取压缩文件(file0, 缓存路径, Config.LANGUAGE_INPUT, Config.LANGUAGE_OUTPUT)
            file3 = Module.读取压缩文件(file1, 缓存路径, Config.LANGUAGE_INPUT, Config.LANGUAGE_OUTPUT) if file1 else []
            if not any(isinstance(item, list) and len(item) > 0 and item[0] == Config.LANGUAGE_INPUT.lower() for item in file2[1:]):
                Module.写入日志("[读取资源文件] file0中没有原语言文件", info_level=3)
                raise FileNotFoundError("[读取资源文件] file0: 没有原始语言文件")
            if file1 and not any(isinstance(item, list) and len(item) > 0 and item[0] == Config.LANGUAGE_OUTPUT.lower() for item in file3[1:]):
                Module.写入日志("[读取资源文件] file1中没有目标语言文件", info_level=3)
                raise FileNotFoundError("[读取资源文件] file1: 没有目标语言文件")
            for index in file2[1:]:
                if index[0] == Config.LANGUAGE_INPUT.lower():
                    文件0 = index[1]
                    压缩路径 = index[1]
            if file3:
                for index in file3[1:]:
                    if index[0] == Config.LANGUAGE_OUTPUT.lower():
                        文件1 = index[1]
            else:
                for index in file2[1:]:
                    if index[0] == Config.LANGUAGE_OUTPUT.lower():
                        文件1 = index[1]
            输出扩展名 = Path(文件0).suffix
            文件0, 文件0源文件 = Module.读取语言文件(文件0)
            if 文件1:
                文件1, _ = Module.读取语言文件(文件1)
        elif Path(file0).suffix in [".lang", ".json"]:
            文件0, 文件0源文件 = Module.读取语言文件(file0)
            if file1:
                文件1, _ = Module.读取语言文件(file1)
            输出扩展名 = Path(file0).suffix
        return 文件0, 文件0源文件, 文件1, 压缩路径, 输出扩展名, file2
    def 翻译缓存(输入列表: list = []):
        文本文件 = []
        try:
            with open(f"{Config.TRANSLATOR_CACHE_PATH}/{Config.TRANSLATOR_CACHE_NAME}.pkl", "rb+") as f:
                文本文件 = pickle.load(f)
        except Exception: pass
        if 输入列表:
            文本文件.extend(输入列表)
            with open(f"{Config.TRANSLATOR_CACHE_PATH}/{Config.TRANSLATOR_CACHE_NAME}.pkl", "wb+") as f:
                pickle.dump(文本文件, f)
        return {item[0]: item[1] for item in 文本文件}, {item[0] for item in 文本文件}